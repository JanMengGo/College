<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="homepageCSS.css">
<title>Reported Incident</title>
</head>

<body>
<nav>
    <ul>
      <li><a href="admin_homepage.php">Home</a></li>
      <li><a href="admin_reportedIncidents.php">Reported incident</a></li>
      <li><a href="admin_statistics.php">Reports</a></li>
      <li><a href="addUsertype.php">Usertype</a></li>
      <li><a href="addedStatus.php">Add status</a></li>
      <li><a href="addedAction.php">Add action</a></li>
      <li><a href="addedEmergency.php">Add emergency type</a></li>
      <li><a href="addedIntensity.php">Add Intensity</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

<div class="container">
    <?php
  
    $conn = new mysqli("localhost", "root", "", "ibrt_alert");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

   
    $sql = "SELECT * FROM report_details";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                  <th>Emergency Type</th>
                  <th>Location</th>
                  <th>Reported time</th>
                  <th>Description</th>
                  <th>Intensity</th>
                  <th>Status</th>
                  <th>Action made</th>
                  <th>Remarks</th>
                  <th></th>
                </tr>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["RD_EM_TYPE"] . "</td>
                    <td>" . $row["RD_LOCATION"] . "</td>
                    <td>" . date("h:i:s A", strtotime($row["RD_TIME"])) . "</td>
                    <td>" . $row["RD_DESCRIPTION"] . "</td>
                    <td>" . $row["RD_INTENSITY"] . "</td>
                    <td>" . ($row["RD_STATUS"] ?: "Pending") . "</td>
                    <td>" . $row["RD_ACTION"] . "</td>
                    <td>" . $row["RD_REMARKS"] . "</td>
                    <td>
                        <a href='admin_updateReport.php?reportID=" . $row["RD_ID"] . "' class='update-button'>Update</a>
                        <a href='admin_deleteReport.php?id=" . $row["RD_ID"] . "' class='delete-button' onclick='return confirm(\"Are you sure you want to delete this record?\")'>Delete</a>
                    </td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "No data available.";
    }

    
    $conn->close();
    ?>
</div>

<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .container {
        margin: 20px;
        width: 100%;
        margin-left: 20px;
    }

    .update-button {
    background-color: #4CAF50;
    color: white;
    padding: 6px 12px;
    border: none;
    border-radius: 4px;
    text-decoration: none;
}

.delete-button {
    background-color: #f44336;
    color: white;
    padding: 6px 12px;
    border: none;
    border-radius: 4px;
    text-decoration: none;
}
body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }
</style>
</body>
</html>
