<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="homepageCSS.css">
<title>Reported Incident</title>
</head>

<body>
<nav>
  <ul>
    <li><a href="homepage.php">Home</a></li>
    <li><a href="reportNow.php">Report now</a></li>
    <li><a href="reportedIncidents.php">Reported incident</a></li>
    <li><a href="#"><img src="logo.png" alt="Logo"></a></li>
    <li><a href="">Resolved reports</a></li>
    <li><a href="">Responders</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<div class="container">
    <?php
    // Create connection
    $conn = new mysqli("localhost", "root", "", "ibrt_alert");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve data from the database
    $sql = "SELECT * FROM report_details";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                  <th>Emergency Type</th>
                  <th>Location</th>
                  <th>Reported time</th>
                  <th>Description</th>
                  <th>Intensity</th>
                  <th>Status</th>
                  <th>Action made</th>
                  <th>Remarks</th>
                  <th></th>
                </tr>";
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["RD_EM_TYPE"] . "</td>
                    <td>" . $row["RD_LOCATION"] . "</td>
                    <td>" . date("h:i:s A", strtotime($row["RD_TIME"])) . "</td>
                    <td>" . $row["RD_DESCRIPTION"] . "</td>
                    <td>" . $row["RD_INTENSITY"] . "</td>
                    <td>" . ($row["RD_STATUS"] ?: "Pending") . "</td>
                    <td>" . $row["RD_ACTION"] . "</td>
                    <td>" . $row["RD_REMARKS"] . "</td>
                   
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "No data available.";
    }

    // Close the connection
    $conn->close();
    ?>
</div>


  <style>
    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    .container {
      margin-top: 50px;
      width: 1700px;
    }

    
  </style>
</body>
</html>
