<?php
// Create connection to the database
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check the connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if the form has been submitted
if (isset($_POST['course'])) {
  // Get the course from the form
  $course = $_POST['course'];

  // Delete the course from the added_course table
  $sql = "DELETE FROM added_course WHERE AC_NAME='$course'";
  if ($conn->query($sql) === TRUE) {
    echo "<script>
    alert('Course deleted successfully.');
    window.location.href = 'addedCourse.php';
</script>";
  } else {
    echo "Error deleting course: " . $conn->error;
  }
}

// Close the database connection
$conn->close();
?>
