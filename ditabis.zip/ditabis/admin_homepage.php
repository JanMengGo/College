<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="homepageCSS.css">
<title>Login Form</title>
</head>

<body>
<nav>
    <ul>
      <li><a href="admin_homepage.php">Home</a></li>
      <li><a href="admin_reportedIncidents.php">Reported incident</a></li>
      <li><a href="admin_statistics.php">Reports</a></li>
      <li><a href="addUsertype.php">Usertype</a></li>
      <li><a href="addedStatus.php">Add status</a></li>
      <li><a href="addedAction.php">Add action</a></li>
      <li><a href="addedEmergency.php">Add emergency type</a></li>
      <li><a href="addedIntensity.php">Add Intensity</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>
<body>
<div class="containerHP">
  <div class="content-large"> Reported Incidents</div>
>
 <div class="content-small2">Latest Incidents</div>
 <div class="content-small3">Emergency Hotlines</div>
</div> 
  <footer>
    <p>&copy; 2023 IBRT Alert. All rights reserved.</p>
  </footer>
</body>

</html>