-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2023 at 02:33 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ibrt_alert`
--

-- --------------------------------------------------------

--
-- Table structure for table `added_action`
--

CREATE TABLE `added_action` (
  `AA_ID` varchar(12) NOT NULL,
  `AA_NAME` text NOT NULL,
  `AA_DATEADDED` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `added_action`
--

INSERT INTO `added_action` (`AA_ID`, `AA_NAME`, `AA_DATEADDED`) VALUES
('398522919014', 'test emergency type', '2023-05-24 20:06:41'),
('401663369877', 'Call Emergency Medical Services', '2023-05-22 22:11:22'),
('445063034506', 'Provide First Aid', '2023-05-22 22:11:01'),
('778300412324', 'emergency', '2023-05-24 20:04:49');

-- --------------------------------------------------------

--
-- Table structure for table `added_course`
--

CREATE TABLE `added_course` (
  `AC_ID` varchar(12) NOT NULL,
  `AC_NAME` text NOT NULL,
  `AC_DATEADDED` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `added_course`
--

INSERT INTO `added_course` (`AC_ID`, `AC_NAME`, `AC_DATEADDED`) VALUES
('154792338275', 'Bachelor of Science in Electronics Engineering', '2023-05-24'),
('648232780489', 'Bachelor of Science in Information Technology', '2023-05-24'),
('852086294111', 'Bachelor of Technical Vocational Teacher Education', '2023-05-24'),
('871836201421', 'Bachelor of Science in Computer Engineering', '2023-05-24'),
('909055026445', 'Bachelor of Science in Information Systems', '2023-05-24');

-- --------------------------------------------------------

--
-- Table structure for table `added_emergencytype`
--

CREATE TABLE `added_emergencytype` (
  `AE_ID` varchar(12) NOT NULL,
  `AE_NAME` text NOT NULL,
  `AE_DATEADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `added_emergencytype`
--

INSERT INTO `added_emergencytype` (`AE_ID`, `AE_NAME`, `AE_DATEADDED`) VALUES
('179919969281', 'medical', '2023-05-28 17:01:42'),
('395843307331', 'test emergency type', '2023-05-24 14:08:23'),
('687772215526', 'fire', '2023-05-28 17:01:50');

-- --------------------------------------------------------

--
-- Table structure for table `added_intensity`
--

CREATE TABLE `added_intensity` (
  `AI_ID` varchar(12) NOT NULL,
  `AI_NAME` text NOT NULL,
  `AI_DATEADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `added_intensity`
--

INSERT INTO `added_intensity` (`AI_ID`, `AI_NAME`, `AI_DATEADDED`) VALUES
('100031733571', 'test intensity', '2023-05-24 00:00:00'),
('312289849808', 'mild', '2023-05-24 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `added_major`
--

CREATE TABLE `added_major` (
  `AM_iD` varchar(12) NOT NULL,
  `AM_NAME` text NOT NULL,
  `AM_DATEADDED` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `added_major`
--

INSERT INTO `added_major` (`AM_iD`, `AM_NAME`, `AM_DATEADDED`) VALUES
('515714992265', 'major bing', '2023-05-28');

-- --------------------------------------------------------

--
-- Table structure for table `added_status`
--

CREATE TABLE `added_status` (
  `AS_ID` varchar(12) NOT NULL,
  `AS_STATUS` text NOT NULL,
  `AS_DATEADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `added_status`
--

INSERT INTO `added_status` (`AS_ID`, `AS_STATUS`, `AS_DATEADDED`) VALUES
('365991586632', 'In progress', '0000-00-00 00:00:00'),
('701354777704', 'test status', '0000-00-00 00:00:00'),
('766815090580', 'Resolved', '0000-00-00 00:00:00'),
('794692237311', 'test b', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `added_usertype`
--

CREATE TABLE `added_usertype` (
  `AU_ID` varchar(12) NOT NULL,
  `AU_ROLE` text DEFAULT NULL,
  `AU_DATEADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `added_usertype`
--

INSERT INTO `added_usertype` (`AU_ID`, `AU_ROLE`, `AU_DATEADDED`) VALUES
('112064776834', 'student', '2023-05-22 09:48:49'),
('126405589164', 'nurse', '2023-05-22 09:48:52'),
('513640715614', 'admin', '2023-05-22 09:48:46');

-- --------------------------------------------------------

--
-- Table structure for table `agency`
--

CREATE TABLE `agency` (
  `AG_ID` int(12) NOT NULL,
  `AG_CONTACT_NUM` int(12) NOT NULL,
  `AG_CONTACT_PERSON` text NOT NULL,
  `AG_NAME` text NOT NULL,
  `AG_DATE_ADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `COURSE_ID` varchar(12) NOT NULL,
  `COURSE_NAME` text NOT NULL,
  `COURSE_DATE_ADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`COURSE_ID`, `COURSE_NAME`, `COURSE_DATE_ADDED`) VALUES
('676860808701', 'Bachelor of Science in Information Technology', '2023-05-28 23:00:23');

-- --------------------------------------------------------

--
-- Table structure for table `emergency`
--

CREATE TABLE `emergency` (
  `EM_ID` int(12) NOT NULL,
  `EM_TYPE_ID` int(12) NOT NULL,
  `EM_NAME` text NOT NULL,
  `EM_DATE_ADDED` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `em_type`
--

CREATE TABLE `em_type` (
  `EM_TYPE_ID` varchar(12) NOT NULL,
  `EM_TYPE` varchar(60) NOT NULL,
  `EM_DATE_ADDED` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `major`
--

CREATE TABLE `major` (
  `MAJOR_ID` varchar(12) NOT NULL,
  `MAJ_NAME` varchar(60) NOT NULL,
  `MAJ_DATE_ADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `major`
--

INSERT INTO `major` (`MAJOR_ID`, `MAJ_NAME`, `MAJ_DATE_ADDED`) VALUES
('998119787171', '', '2023-05-28 23:00:23');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `REPORT_ID` int(12) NOT NULL,
  `STU_ID` int(12) NOT NULL,
  `REPORT_DATE_ADDED` date NOT NULL,
  `REPORT_TIME` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_details`
--

CREATE TABLE `report_details` (
  `RD_ID` varchar(12) NOT NULL,
  `RD_INTENSITY` varchar(12) NOT NULL,
  `RD_LOCATION` varchar(60) NOT NULL,
  `RD_REMARKS` varchar(60) NOT NULL,
  `RD_STATUS` varchar(60) NOT NULL,
  `RD_EM_TYPE` varchar(11) NOT NULL,
  `RD_DESCRIPTION` varchar(60) NOT NULL,
  `RD_ACTION` varchar(60) NOT NULL,
  `RD_DATE` date NOT NULL,
  `RD_TIME` time(6) NOT NULL,
  `DATE_ADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_details`
--

INSERT INTO `report_details` (`RD_ID`, `RD_INTENSITY`, `RD_LOCATION`, `RD_REMARKS`, `RD_STATUS`, `RD_EM_TYPE`, `RD_DESCRIPTION`, `RD_ACTION`, `RD_DATE`, `RD_TIME`, `DATE_ADDED`) VALUES
('447388066443', 'Mild', 'TESTpeND', '', '', 'Medical', 'PEND', 'Call Emergency Medical Services', '2023-05-23', '20:24:56.000000', '2023-05-23 00:00:00'),
('523185104682', 'Moderate', 'TEST PENDING', '', '', 'Medical', 'PENDING', '', '2023-05-23', '20:22:00.000000', '2023-05-23 00:00:00'),
('602194001599', 'Moderate', 'a', '', 'In progress', 'Medical', 'test', '', '2023-05-24', '20:03:41.000000', '2023-05-23 00:00:00'),
('698597984886', 'mild', 'field', '', '', 'fire', 'a', '', '2024-11-20', '00:00:00.000000', '0000-00-00 00:00:00'),
('717008456159', 'test intensi', 'field', '', '', 'test emerge', 'ada', '', '2023-08-10', '00:00:00.000000', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `STUDENT` int(11) NOT NULL,
  `COURSE_ID` varchar(12) NOT NULL,
  `MAJOR_ID` varchar(12) NOT NULL,
  `UA_ID` varchar(12) NOT NULL,
  `UT_ID` varchar(12) NOT NULL,
  `STU_FNAME` text NOT NULL,
  `STU_MNAME` text NOT NULL,
  `STU_LNAME` text NOT NULL,
  `AGE` int(2) NOT NULL,
  `STU_DATE_ADDED` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UA_ID` varchar(12) NOT NULL,
  `UA_USERNAME` varchar(60) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `UA_PASS` varchar(60) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `UA_ROLE` varchar(12) NOT NULL,
  `UA_DATE_ADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UA_ID`, `UA_USERNAME`, `UA_PASS`, `UA_ROLE`, `UA_DATE_ADDED`) VALUES
('641645909384', 'admin', 'admin123', 'admin', '2023-05-28 23:00:23');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `UT_ID` varchar(12) NOT NULL,
  `UT_ROLE` text NOT NULL,
  `UT_DATE_ADDED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`UT_ID`, `UT_ROLE`, `UT_DATE_ADDED`) VALUES
('283700', 'admin', '2023-05-28 23:00:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `added_action`
--
ALTER TABLE `added_action`
  ADD PRIMARY KEY (`AA_ID`);

--
-- Indexes for table `added_course`
--
ALTER TABLE `added_course`
  ADD PRIMARY KEY (`AC_ID`);

--
-- Indexes for table `added_emergencytype`
--
ALTER TABLE `added_emergencytype`
  ADD PRIMARY KEY (`AE_ID`);

--
-- Indexes for table `added_intensity`
--
ALTER TABLE `added_intensity`
  ADD PRIMARY KEY (`AI_ID`);

--
-- Indexes for table `added_major`
--
ALTER TABLE `added_major`
  ADD PRIMARY KEY (`AM_iD`);

--
-- Indexes for table `added_status`
--
ALTER TABLE `added_status`
  ADD PRIMARY KEY (`AS_ID`);

--
-- Indexes for table `added_usertype`
--
ALTER TABLE `added_usertype`
  ADD PRIMARY KEY (`AU_ID`);

--
-- Indexes for table `agency`
--
ALTER TABLE `agency`
  ADD PRIMARY KEY (`AG_ID`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`COURSE_ID`);

--
-- Indexes for table `emergency`
--
ALTER TABLE `emergency`
  ADD PRIMARY KEY (`EM_ID`),
  ADD UNIQUE KEY `EM_TYPE_ID` (`EM_TYPE_ID`);

--
-- Indexes for table `em_type`
--
ALTER TABLE `em_type`
  ADD PRIMARY KEY (`EM_TYPE_ID`);

--
-- Indexes for table `major`
--
ALTER TABLE `major`
  ADD PRIMARY KEY (`MAJOR_ID`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`REPORT_ID`),
  ADD UNIQUE KEY `STU_ID` (`STU_ID`);

--
-- Indexes for table `report_details`
--
ALTER TABLE `report_details`
  ADD PRIMARY KEY (`RD_ID`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`STUDENT`),
  ADD UNIQUE KEY `COURSE_ID` (`COURSE_ID`),
  ADD UNIQUE KEY `MAJOR_ID` (`MAJOR_ID`),
  ADD KEY `UT_ID` (`UT_ID`),
  ADD KEY `UA_ID` (`UA_ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UA_ID`);

--
-- Indexes for table `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`UT_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `student_info`
--
ALTER TABLE `student_info`
  ADD CONSTRAINT `student_info_ibfk_1` FOREIGN KEY (`COURSE_ID`) REFERENCES `course` (`COURSE_ID`),
  ADD CONSTRAINT `student_info_ibfk_2` FOREIGN KEY (`UT_ID`) REFERENCES `user_type` (`UT_ID`),
  ADD CONSTRAINT `student_info_ibfk_3` FOREIGN KEY (`MAJOR_ID`) REFERENCES `major` (`MAJOR_ID`),
  ADD CONSTRAINT `student_info_ibfk_4` FOREIGN KEY (`UA_ID`) REFERENCES `user` (`UA_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
