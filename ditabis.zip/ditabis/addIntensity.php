<?php
// Create connection to the database
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit1'])) {
    // Prepare and bind statement for added_intensity table
    $stmt = $conn->prepare("INSERT INTO added_intensity (AI_ID, AI_NAME, AI_DATEADDED) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $aiId, $aiName, $aiDateAdded);

    // Set form data
    $aiId = rand(pow(10, 11), pow(10, 12) - 1); // Generate unique ID for AI_ID
    $aiName = $_POST['textarea1'];
    $aiDateAdded = date("Y-m-d"); // Current date

    // Execute statement for added_intensity table
    if ($stmt->execute()) {
        echo "<script>alert('Intensity added!');</script>";
        header("Location: addedIntensity.php");
        exit(); // Terminate the current script
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
}
?>