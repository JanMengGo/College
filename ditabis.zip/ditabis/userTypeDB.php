<?php
date_default_timezone_set('Asia/Manila');
// Create connection to the database
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['Username']) && isset($_GET['Password']) && isset($_GET['Login_usertype'])) {
    $username = $_GET['Username'];
    $password = $_GET['Password'];
    $userType = $_GET['Login_usertype'];

    // Prepare and execute the SQL query to check if the user exists
    $sql = "SELECT * FROM user WHERE UA_USERNAME = '$username' AND UA_PASS = '$password'";
    $result = $conn->query($sql);

    if ($result === false) {
        echo "Error: " . $sql . "<br>" . $conn->error;
    } else {
        if ($result->num_rows === 1) {
            // User exists in the database

            // Get the user's role from the result
            $row = $result->fetch_assoc();
            $userRole = $row['UA_ROLE'];

            // Check if the user role matches the input user type
            if ($userRole === $userType) {
                // Generate user type ID
                $userTypeID = rand(pow(10, 5), pow(10, 6) - 1);

                // Get the current date and time
                $dateTimeAdded = date("Y-m-d H:i:s");

                // Prepare and execute the SQL query to insert user type into the database
                $sql = "INSERT INTO user_type (UT_ID, UT_ROLE, UT_DATE_ADDED) VALUES ('$userTypeID', '$userType', '$dateTimeAdded')";
                if ($conn->query($sql) === TRUE) {
                    if ($userRole === 'admin' || $userRole === 'nurse') {
                        echo "<script>alert('Login successful! Welcome, $userRole');</script>";
                        echo "<script>window.location = 'admin_homepage.php';</script>";
                        exit();
                    } else {
                        echo "<script>alert('Login successful! Welcome, $userRole');</script>";
                        echo "<script>window.location = 'homepage.php';</script>";
                        exit();
                    }
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                echo "<script>alert('Login Failed. Invalid user role');</script>";
                echo "<script>window.location = 'loginform3.php';</script>";
                exit();
            }
        } else {
            echo "<script>alert('Login Failed. Invalid username or password');</script>";
            echo "<script>window.location = 'loginform.php';</script>";
            exit();
        }
    }
} else {
    echo "<script>alert('Error: Missing fields are required');</script>";
    echo "<script>window.location = 'loginform.php';</script>";
}

// Close the database connection
$conn->close();
?>
