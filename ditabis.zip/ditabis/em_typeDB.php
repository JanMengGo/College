<?php
date_default_timezone_set('Asia/Manila');
// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Create connection
    $conn = new mysqli("localhost", "root", "", "ibrt_alert");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind statement for em_type table
    $stmt = $conn->prepare("INSERT INTO em_type (EM_TYPE_ID, EM_TYPE, EM_DATE_ADDED) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $emTypeId, $emType, $dateAdded);

    // Set form data
    $dateAdded = date("Y-m-d"); // Current date

    // Get emergency type from GET data
    $emType = $_GET['emergency_type'];

    // Generate unique ID for EM_TYPE_ID
    $emTypeId = rand(pow(10, 11), pow(10, 12) - 1);

    // Execute statement for em_type table
    if ($stmt->execute()) {
        echo "<script>alert('Report submitted!');</script>";
        echo "<script>window.location = 'homepage.php';</script>";
        exit(); // Terminate the current script
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
