<?php 
date_default_timezone_set('Asia/Manila');
// Create connection
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// Retrieve the form data
$firstName = $_GET["STU_FNAME"];
$middleName = $_GET["MNAME"];
$lastName = $_GET["STU_LNAME"];
$age = $_GET["Age"];
// Generate a course ID with 12 integers
$studentID = rand(pow(10,11), pow(10,12)-1);


 // Get the foreign key values from other tables
 $courseID = getCourseID($conn);
 $majorID = getMajorID($conn);
 $uaID = getUserID($conn);
 $utID = getUserTypeID($conn);
 
 // Prepare and execute the SQL query to insert the student information
 $stmt = $conn->prepare("INSERT INTO student_info (STUDENT, COURSE_ID, MAJOR_ID, UA_ID, UT_ID, STU_FNAME, STU_MNAME, STU_LNAME, AGE, STU_DATE_ADDED) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE())");
 $stmt->bind_param("ssssssssi", $studentID, $courseID, $majorID, $uaID, $utID, $firstName, $middleName, $lastName, $age);

 $stmt->execute();

 if ($stmt->affected_rows == 1) {
   echo "Student information inserted successfully!";
 } else {
   echo "Failed to insert student information.";
 }

 $stmt->close();

// Close the database connection



// Function to retrieve the course ID from another table
function getCourseID($conn) {
  // Prepare and execute the SQL query
  $stmt = $conn->prepare("SELECT COURSE_ID FROM course");
  $stmt->execute();
  $stmt->bind_result($courseID);
  $stmt->fetch();
  $stmt->close();

  return $courseID;
}n $courseID;

function getMajorID() {
    $stmt = $conn->prepare("SELECT MAJOR_ID FROM major");
  $stmt->execute();
  $stmt->bind_result($majorID);
  $stmt->fetch();

  $stmt->close();

  return $majorID;
  }
  function getUserID() {
    $stmt = $conn->prepare("SELECT UA_ID FROM user");
    $stmt->execute();
    $stmt->bind_result($uaID);
    $stmt->fetch();
  
    $stmt->close();
  
  
    return $uaID;
  }
  
  // Function to retrieve the UT ID from the user_type table
  function getUserTypeID() {
    $stmt = $conn->prepare("SELECT UT_ID FROM user_type");
    $stmt->execute();
    $stmt->bind_result($utID);
    $stmt->fetch();
  
    $stmt->close();
 
  
    return $utID;
  }




?>