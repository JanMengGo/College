<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="homepageCSS.css">
<title>Reported Incident</title>
<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .container {
        margin: 20px;
        width: 100%;
        margin-left: 20px;
    }
body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }

    .search-container {
        display: flex;
        float: left;
        align-items: center;
    }

    .search-container input[type="text"] {
        height: 30px;
    padding: 0 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
    margin-right: 10px; 
    }

    .search-container button[type="submit"] {
        
        height: 30px;
        padding: 0 10px;
        margin-left: 150px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 3px;
        cursor: pointer;
        margin-left: auto;
    }
    
    .sort-container {
        display: flex;
        align-items: center;
        margin-top: 10px;
    }
    
    .sort-container label {
        margin-right: 10px;
    }
  
</style>
</head>

<body>
<nav>
    <ul>
      <li><a href="admin_homepage.php">Home</a></li>
      <li><a href="admin_reportedIncidents.php">Reported incident</a></li>
      <li><a href="admin_statistics.php">Reports</a></li>
      <li><a href="addUsertype.php">Usertype</a></li>
      <li><a href="addedStatus.php">Add status</a></li>
      <li><a href="addedAction.php">Add action</a></li>
      <li><a href="addedEmergency.php">Add emergency type</a></li>
      <li><a href="addedIntensity.php">Add Intensity</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

<div class="container">
    <div class="search-container">
        <form method="GET" action="">
            <input type="text" name="search" placeholder="Search..."> 
     
            <button type="submit" >Search</button>
            
        </form>
    </div>
    
   

    <?php
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$search = isset($_GET['search']) ? $_GET['search'] : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : '';
$order = 'RD_DATE DESC';
switch ($sort) {
    case 'day':
        $order = 'RD_DATE DESC';
        break;
    case 'week':
        $order = 'WEEK(RD_DATE) DESC';
        break;
    case 'month':
        $order = 'MONTH(RD_DATE) DESC';
        break;
    case 'year':
        $order = 'YEAR(RD_DATE) DESC';
        break;
}

$whereClause = "";
if (!empty($search)) {
    // Check if the search input is a valid year
    if (is_numeric($search) && strlen($search) === 4) {
        $whereClause = "WHERE YEAR(RD_DATE) = $search";
    } else {
        // Check if the search input is a valid month name
        $monthNumber = date_parse($search)['month'];
        if ($monthNumber) {
            $whereClause = "WHERE MONTH(RD_DATE) = $monthNumber";
        } else {
            $whereClause = "WHERE 
                RD_LOCATION LIKE '%$search%' 
                OR RD_INTENSITY LIKE '%$search%'
                OR RD_REMARKS LIKE '%$search%'
                OR RD_STATUS LIKE '%$search%'
                OR RD_EM_TYPE LIKE '%$search%'
                OR RD_DESCRIPTION LIKE '%$search%'
                OR RD_ACTION LIKE '%$search%'
                OR RD_DATE LIKE '%$search%'
                OR RD_TIME LIKE '%$search%'
                OR DATE_ADDED LIKE '%$search%'";
        }
    }
}

$sql = "SELECT * FROM report_details $whereClause ORDER BY $order";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table>
            <tr>
              <th>Emergency Type</th>
              <th>Location</th>
              <th>Reported Date</th>
              <th>Reported Time</th>
              <th>Description</th>
              <th>Intensity</th>
              <th>Status</th>
              <th>Action made</th>
              <th>Remarks</th>
              <th></th>
            </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["RD_EM_TYPE"] . "</td>
                <td>" . $row["RD_LOCATION"] . "</td>
                <td>" . date("Y-m-d", strtotime($row["RD_DATE"])) . "</td>
                <td>" . date("h:i:s A", strtotime($row["RD_TIME"])) . "</td>
                <td>" . $row["RD_DESCRIPTION"] . "</td>
                <td>" . $row["RD_INTENSITY"] . "</td>
                <td>" . ($row["RD_STATUS"] ?: "Pending") . "</td>
                <td>" . $row["RD_ACTION"] . "</td>
                <td>" . $row["RD_REMARKS"] . "</td>
                
              </tr>";
    }
    echo "</table>";
} else {
    echo "No matching data found.";
}

$conn->close();
?>



</div>

</body>
</html>
