<?php
// Create connection to the database
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check the connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if the form has been submitted
if (isset($_POST['major'])) {
  // Get the major name from the form
  $major = $_POST['major'];

  // Delete the major from the added_major table
  $sql = "DELETE FROM added_major WHERE AM_NAME='$major'";
  if ($conn->query($sql) === TRUE) {
    // Successfully deleted the major
    header("Location: addedMajor.php"); // Redirect back to the main page
    exit();
  } else {
    echo "Error deleting major: " . $conn->error;
  }
}

// Close the database connection
$conn->close();
?>
