<?php
// Create a connection to the database
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    // Generate a random 12-digit ID
    $randomId = rand(100000000000, 999999999999);

    // Retrieve the form data
    $intensity = $_GET["intensity"];
    $emergencyType = $_GET["emergency_type"];
    $location = $_GET["location"];
    $description = $_GET["description"];

    // Prepare the SQL statement to insert the data into the report_details table
    $sql = "INSERT INTO report_details (RD_ID, RD_INTENSITY, RD_EM_TYPE, RD_LOCATION, RD_DESCRIPTION) 
            VALUES ('$randomId', '$intensity', '$emergencyType', '$location', '$description')";

    // Execute the SQL statement
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Report added!');</script>";
        header("Location: reportedIncidents.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        header("Location: reportNow.php");
        exit();
    }
}

// Close the database connection
$conn->close();
?>
