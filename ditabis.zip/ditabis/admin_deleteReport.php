<?php
// Create connection to the database
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the ID parameter exists
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare and execute the SQL query to delete the record
    $sql = "DELETE FROM report_details WHERE RD_ID = '$id'";
    if ($conn->query($sql) === TRUE) {
        // Deletion successful
        echo "<script>alert('Record deleted successfully');</script>";
        echo "<script>window.location = 'admin_reportedIncidents.php';</script>";
    } else {
        // Error occurred during deletion
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // ID parameter is missing
    echo "Error: ID parameter is missing";
}

// Close the database connection
$conn->close();
?>
