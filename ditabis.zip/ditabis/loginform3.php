<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="style3.css" />
    <title>Login Form</title>
  </head>
  <body>
    <?php 
$conn = new mysqli("localhost", "root", "", "ibrt_alert");


if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }
    $result = $conn->query("SELECT AU_ROLE FROM added_usertype"); $userTypes =
    $result->fetch_all(MYSQLI_ASSOC); ?>

    <div class="container" id="container">
      <div class="form-container sign-up-container">
        <form action="submitForm.php" method="GET">
          <div class="part1">
            <input
              type="text"
              name="STU_FNAME"
              placeholder="First Name"
              required
            />
            <input type="text" name="MNAME" placeholder="Middle Name" />
            <input
              type="text"
              name="STU_LNAME"
              placeholder="Last Name"
              required
            />

            <input id="age" type="text" name="Age" placeholder="Age" required />

            <select name="Course" required class="Major">
            
              <option value="" disabled selected hidden>Course</option>

<option value="Course"></option>
<?php
$sql = "SELECT AC_NAME FROM added_course";
$result = $conn->query($sql);
if ($result->num_rows > 0) {    
while ($row = $result->fetch_assoc()) {
$userType = $row['AC_NAME'];
echo "<option value=\"$userType\">$userType</option>";
}
}
?>
   </option>
 </select>

            <select name="Major"  class="Course">
            <option value="" disabled selected hidden>Major</option>

<option value="Major"></option>
<?php
$sql = "SELECT AM_NAME FROM added_major";
$result = $conn->query($sql);
if ($result->num_rows > 0) {    
while ($row = $result->fetch_assoc()) {
$userType = $row['AM_NAME'];
echo "<option value=\"$userType\">$userType</option>";
}
}
?>
   </option>
            </select>
          </div>



          <input type="text" name="Username" placeholder="Username" required />
          <input
            type="password"
            name="Password"
            placeholder="Password"
            minlength="8"
            required
          />
          <input
            type="password"
            name="REpassword"
            placeholder="Re-type Password"
            minlength="8"
            required
          />
          <select name="Signup_usertype" required class="option">
            <option value="" disabled selected hidden>User-Type</option>

            <option value="Signup_usertype"></option>
            <?php
            $sql = "SELECT AU_ROLE FROM added_usertype";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {    
           while ($row = $result->fetch_assoc()) {
            $userType = $row['AU_ROLE'];
            echo "<option value=\"$userType\">$userType</option>";
    }
}
?>
          </select>
          <br />
          <button class="buttonSL">Sign Up</button>
        </form>
        <div id="popupDiv" class="popup">
          <h2>Pop-up Content</h2>
          <p>This is the content of the pop-up div.</p>
          <button onclick="closePopup()">Close</button>
        </div>
      </div>

      <div class="form-container sign-in-container">
        <form action="userTypeDB.php" method="GET">
          <h1>Login</h1>
          <br />
          <br />
          <br />
          <span> Please login to your account </span>
          <input type="text" name="Username" placeholder="Username" required />
          <input
            type="password"
            name="Password"
            placeholder="Password"
            minlength="8"
            required
          />

          <select name="Login_usertype" required class="option2">
            <option value="" disabled selected hidden>User-Type</option>

            <option value="Login_usertype"></option>
            <?php
$sql = "SELECT AU_ROLE FROM added_usertype";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $userType = $row['AU_ROLE'];
        echo "<option value=\"$userType\">$userType</option>";
    }
}
?>

          </select>
          <br />

          <button class="buttonSL">Login</button>
        </form>
      </div>

      <div class="overlay-container">
        <div class="overlay">
          <div class="overlay-panel overlay-left">
            <h1>Have an Account?</h1>
            <br />
            <button class="ghost" class="buttonSL" id="signIn">Login</button>
          </div>

          <div class="overlay-panel overlay-right">
            <h1>IBRT Alert</h1>
            <p>
              Our website aims to enhance the safety and security of CHMSU
              Alijis students by enabling them to quickly and easily report any
              issues they encounter. We strive to create a safer and more secure
              campus environment through the power of technology and the
              collaboration of our community.
            </p>
            <button class="ghost" id="signUp" class="buttonSL">
              Student Sign Up
            </button>
            <br />
          </div>
        </div>
      </div>
    </div>

    <script>
      const signUpButton = document.getElementById("signUp");
      const signInButton = document.getElementById("signIn");
      const container = document.getElementById("container");

      signUpButton.addEventListener("click", () => {
        container.classList.add("right-panel-active");
      });

      signInButton.addEventListener("click", () => {
        container.classList.remove("right-panel-active");
      });
      function checkPasswords() {
        var password = document.getElementById("password").value;
        var repassword = document.getElementById("repassword").value;

        if (password !== repassword) {
          showPopup("Passwords do not match");
          disableSignupButton();
        } else {
          document.forms[0].submit();
        }
      }

      function showPopup(message) {
        var popupDiv = document.getElementById("popupDiv");
        popupDiv.querySelector("p").textContent = message;
        popupDiv.style.display = "block";
      }

      function closePopup() {
        var popupDiv = document.getElementById("popupDiv");
        popupDiv.style.display = "none";
      }

      function disableSignupButton() {
        var signupButton = document.querySelector(".buttonSL");
        signupButton.disabled = true;
      }
    </script>
  </body>
</html>
