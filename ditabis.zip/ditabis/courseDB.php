<?php
date_default_timezone_set('Asia/Manila');
// Create connection
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get the course field from the form
$course = $_GET['Course'];
$password = $_GET["Password"];
$repassword = $_GET["REpassword"];
// Check if the password and retype password match
if ($password !== $repassword) {
  
  exit; // Stop further execution
}
// Generate a course ID with 12 integers
$course_id = rand(pow(10,11), pow(10,12)-1);

// Add the current date to the course table
$date_added = date("Y-m-d H:i:s");

// Insert the data into the course table
$sql = "INSERT INTO course (COURSE_ID, COURSE_NAME, COURSE_DATE_ADDED)
VALUES ('$course_id', '$course', '$date_added')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
