<?php

// Assuming you have already established a database connection using mysqli
date_default_timezone_set('Asia/Manila');

// Create connection
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted for adding a new user type
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['userType'])) {
    // Function to generate a unique AU_ID
    $au_id = rand(pow(10, 11), pow(10, 12) - 1);
    $dateAdded = date("Y-m-d h:i:s"); // Current date

    // Retrieve the user type from the form
    $userType = $_POST['userType'];

    // Prepare and execute the SQL query to insert the new user type
    $stmt = $conn->prepare("INSERT INTO added_usertype (AU_ID, AU_ROLE, AU_DATEADDED) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $au_id, $userType, $dateAdded);
    $stmt->execute();

    // Close the statement
    $stmt->close();
}

// Check if form is submitted for deleting a user type
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['auId'])) {
    // Retrieve the AU_ID from the form
    $auId = $_POST['auId'];

    // Prepare and execute the SQL query to delete the user type
    $stmt = $conn->prepare("DELETE FROM added_usertype WHERE AU_ID = ?");
    $stmt->bind_param("s", $auId);
    $stmt->execute();

    // Close the statement
    $stmt->close();
}

// Retrieve all the added user types from the database
$result = $conn->query("SELECT * FROM added_usertype");
$userTypes = $result->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$conn->close();
?>

<!-- HTML form to add a new user type -->
<style>
    nav {
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #ddd;
		height: 50px;
		position: fixed;
		top: 0;
		width: 100%;
	  }
	  
	  nav ul {
		display: flex;
		list-style: none;
		margin: 0;
		padding: 0;
	  }
	  
	  nav li {
		margin: 0 10px;
	  }
	  
	  nav a {
		color: #000;
		text-decoration: none;
		font-size: 18px;

	  }


      table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    .container {
      margin-top: 50px;
      width: 1200px;
    }
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }
    
</style>
<nav>
    <ul>
      <li><a href="admin_homepage.php">Home</a></li>
      <li><a href="admin_reportedIncidents.php">Reported incident</a></li>
      <li><a href="">Resolved reports</a></li>
      <li><a href="">Responders</a></li>
      <li><a href="addUsertype.php">Usertype</a></li>
      <li><a href="addedStatus.php">Add status</a></li>
      <li><a href="addedAction.php">Add action</a></li>
      <li><a href="addedEmergency.php">Add emergency type</a></li>
      <li><a href="addedIntensity.php">Add Intensity</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>
<br>
<br>
<br>
<br>
<form method="POST">
    <label for="usertype">User Type:</label>
    <input type="text" name="userType" id="userType" required>
    <button type="submit">Add User Type</button>
</form>

<!-- Display the added user types in a table -->
<table>
    <thead>
        <tr>
            <th>AU_ID</th>
            <th>User Type</th>
            <th>Date Added</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($userTypes as $userType): ?>
            <tr>
                <td><?= $userType['AU_ID']; ?></td>
                <td><?= $userType['AU_ROLE']; ?></td>
                <td><?= $userType['AU_DATEADDED']; ?></td>
                <td>
                    <form method="POST" onsubmit="return confirm('Are you sure you want to delete this user type?');">
                        <input type="hidden" name="auId" value="<?= $userType['AU_ID']; ?>">
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
