<?php 
date_default_timezone_set('Asia/Manila');
// Create connection
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Generate 12-digit user ID
$userID = rand(pow(10, 11), pow(10, 12) - 1);

// Retrieve form data
$username = $_GET["Username"];
$password = $_GET["Password"];
$repassword = $_GET["REpassword"];
$userRole = $_GET["Signup_usertype"]; // Retrieve the selected user role

// Check if the password and retype password match
if ($password !== $repassword) {
  echo "<script>alert('Passwords do not match. Please go back and retype the password.');</script>";
  exit; // Stop further execution
}

// Get the current date and time
$dateAdded = date("Y-m-d H:i:s");

// Prepare and execute the SQL query
$sql = "INSERT INTO user (UA_ID, UA_USERNAME, UA_PASS, UA_ROLE, UA_DATE_ADDED) VALUES ('$userID', '$username', '$password', '$userRole', '$dateAdded')";
if ($conn->query($sql) === TRUE) {
  echo "<script>alert('User registered successfully');</script>";
  echo "<script>window.location = 'loginform3.php';</script>";
} else {
  echo "<script>alert('ERROR');</script>";
  echo "<script>window.location = 'loginform3.php';</script>";
}

// Close the database connection
$conn->close();
?>
