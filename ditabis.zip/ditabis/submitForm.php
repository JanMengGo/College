<?php
include("majorDB.php");
include("courseDB.php");
include("userDB.php");
//include("studentInfo.php");
include("UserTypeDB.php");
//$courseID = getCourseID($conn);
//$majorID = getMajorID($conn);
//$uaID = getUserID($conn);
//$utID = getUserTypeID($conn);

if(isset($_GET['STU_FNAME']) && isset($_GET['MNAME']) && isset($_GET['STU_LNAME']) && isset($_GET['Age']) && isset($_GET['Course']) && isset($_GET['Username']) && isset($_GET['Password']) && isset($_GET['REpassword']) && isset($_GET['Signup_usertype'])) {
  $first_name = $_GET['STU_FNAME'];
  $middle_name = $_GET['MNAME'];
  $last_name = $_GET['STU_LNAME'];
  $age = $_GET['Age'];
  $course = $_GET['Course'];
  $major = isset($_GET['Major']) ? $_GET['Major'] : null;
  $username = $_GET['Username'];
  $password = $_GET['Password'];
  $repassword = $_GET['REpassword'];
  $role = $_GET['Signup_usertype'];

  // Check if the password and retype password match
  if ($password !== $repassword) {
    echo "Error: Passwords do not match";
    exit; // Stop further execution
  }

  // Insert the data into the database
  // ...

  echo "Form submitted successfully!";
} else {
  echo "Error: Missing required form data";
}
?>
