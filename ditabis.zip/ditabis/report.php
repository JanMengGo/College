<!DOCTYPE html>
<html>
<head>
	<title>Report Details</title>
	<style>
		nav {
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #ddd;
		height: 50px;
		position: fixed;
		top: 0;
		width: 100%;
	  }
	  
	  nav ul {
		display: flex;
		list-style: none;
		margin: 0;
		padding: 0;
	  }
	  
	  nav li {
		margin: 0 10px;
	  }
	  
	  nav a {
		color: #000;
		text-decoration: none;
		font-size: 18px;
	  }

	</style>
</head>
<nav>
  <ul>
    <li><a href="homepage.php">Home</a></li>
    <li><a href="reportNow.php">Report now</a></li>
    <li><a href="reportedIncidents.php">Reported incident</a></li>
    <li><a href="#"><img src="logo.png" alt="Logo"></a></li>
    <li><a href="reportNow.php">Resolved reports</a></li>
    <li><a href="reportNow.php">Responders</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>
<body>
	<h1>Report Details</h1>
	<table>
		<tr>
			<th>Report ID</th>
			<th>Date</th>
			<th>Time</th>
			<th>Location</th>
			<th>Intensity</th>
			<th>Remarks</th>
			<th>Status</th>
			<th>Description</th>
			<th>Action</th>
		</tr>
		<?php
			// Connect to MySQL database
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "IBRT_ALERT";
			$conn = mysqli_connect($servername, $username, $password, $dbname);

			// Check connection
			if (!$conn) {
				die("Connection failed: " . mysqli_connect_error());
			}

			// Retrieve report details
			$sql = "SELECT * FROM report_details";
			$result = mysqli_query($conn, $sql);

			if (mysqli_num_rows($result) > 0) {
				// Output data of each row
				while($row = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>" . $row["RD_ID"] . "</td>";
					echo "<td>" . $row["RD_DATE"] . "</td>";
					echo "<td>" . $row["RD_TIME"] . "</td>";
					echo "<td>" . $row["RD_LOCATION"] . "</td>";
					echo "<td>" . $row["RD_INTENSITY"] . "</td>";
					echo "<td>" . $row["RD_REMARKS"] . "</td>";
					echo "<td>" . $row["RD_STATUS"] . "</td>";
					echo "<td>" . $row["RD_DESCRIPTION"] . "</td>";
					echo "<td>" . $row["RD_ACTION"] . "</td>";
					echo "</tr>";
				}
			} else {
				echo "0 results";
			}

			// Close MySQL database connection
			mysqli_close($conn);
		?>
	</table>
  <button><a href="forms.php">ADD NEW REPORT</a></button>
</body>
</html>
