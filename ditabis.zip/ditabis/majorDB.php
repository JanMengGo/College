<?php
date_default_timezone_set('Asia/Manila');
// Create connection
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get the major field from the form
$major = $_GET['Major'];
$password = $_GET["Password"];
$repassword = $_GET["REpassword"];
// Check if the password and retype password match
if ($password !== $repassword) {
  echo "<script>alert('Passwords do not match. Please go back and retype the password.');</script>";
  exit; // Stop further execution
}
// Generate a major ID with 12 integers
$major_id = rand(100000000000, 999999999999);


// Check if the generated ID already exists in the database
$sql = "SELECT * FROM major WHERE MAJOR_ID = $major_id";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // Regenerate the ID if it already exists
  $major_id = rand(pow(10,11), pow(10,12)-1);
}

// Add the current date to the major table
$date_added = date("Y-m-d H:i:s");

// Insert the data into the major table
$sql = "INSERT INTO major (MAJOR_ID, MAJ_NAME, MAJ_DATE_ADDED)
VALUES ('$major_id', '$major', '$date_added')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
