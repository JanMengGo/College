<?php
// Check if the form is submitted
if (isset($_POST['submit2'])) {
    // Retrieve the textarea value
    $newAction = $_POST['textarea2'];

    // Generate a unique ID with 12 digits
    $uniqueID = mt_rand(100000000000, 999999999999);

    // Create a connection to the database
    $conn = new mysqli("localhost", "root", "", "ibrt_alert");

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL query to insert the new action
    $sql = "INSERT INTO added_action (AA_ID, AA_NAME, AA_DATEADDED) VALUES ('$uniqueID', '$newAction', NOW())";

    if ($conn->query($sql) === TRUE) {
        // Redirect to a success page or display a success message
        echo "<script>
                alert('New action added successfully!');
                window.location.href = 'admin_homepage.php';
            </script>";
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>
