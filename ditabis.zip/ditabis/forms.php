<!DOCTYPE html>
<html>
<head>
	<title>Report Details</title>
</head>
<body>
<nav>
  <ul>
    <li><a href="homepage.php">Home</a></li>
    <li><a href="reportNow.php">Report now</a></li>
    <li><a href="reportedIncidents.php">Reported incident</a></li>
    <li><a href="#"><img src="logo.png" alt="Logo"></a></li>
    <li><a href="reportNow.php">Resolved reports</a></li>
    <li><a href="reportNow.php">Responders</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>
	<h1>Report Details</h1>
	
	<?php
		// Connect to MySQL database
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "IBRT_ALERT";
		$conn = mysqli_connect($servername, $username, $password, $dbname);

		// Check connection
		if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
		}
		
		// Validate inputs and use default values if necessary
		$date = $_POST['date'] ?? date('Y-m-d');
		$time = $_POST['time'] ?? date('H:i:s');
		$intensity = mysqli_real_escape_string($conn, $_POST['intensity'] ?? '');
		$remarks = mysqli_real_escape_string($conn, $_POST['remarks'] ?? '');
		$status = mysqli_real_escape_string($conn, $_POST['status'] ?? '');
		$description = mysqli_real_escape_string($conn, $_POST['description'] ?? '');
		$action = mysqli_real_escape_string($conn, $_POST['action'] ?? '');
		
		// Insert report details into "report_details" table
		$sql = "INSERT INTO report_details (RD_DATE, RD_TIME, RD_INTENSITY, RD_REMARKS, RD_STATUS, RD_DESCRIPTION, RD_ACTION) VALUES ('$date', '$time', '$intensity', '$remarks', '$status', '$description', '$action')";
		
		if (mysqli_query($conn, $sql)) {
			echo "Report details inserted successfully.";
		} else {
			echo "Error inserting report details: " . mysqli_error($conn);
		}
		
		// Close MySQL database connection
		mysqli_close($conn);
	?>
	
	<form method="post" action="">
		<label>Date:</label>
		<input type="date" name="date"><br><br>
		
		<label>Time:</label>
		<input type="time" name="time"><br><br>
		
		<label>Intensity:</label>
		<input type="text" name="intensity"><br><br>
		
		<label>Remarks:</label>
		<textarea name="remarks"></textarea><br><br>
		
		<label>Status:</label>
		<input type="text" name="status"><br><br>
		
		<label>Description:</label>
		<textarea name="description"></textarea><br><br>
		
		<label>Action:</label>
		<textarea name="action"></textarea><br><br>
		
		<input type="submit" value="Submit">
	</form>
	<button>	<a href="report.php">See Reports</a></button>
</body>
</html>
