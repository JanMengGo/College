<html>
<head>
  <title> </title>
</head>
<body>
<style>
    /* CSS styles for the form and tables */
    .container {
      width: 1000px;
      margin: 10px;
      float: left;
      padding: 20px;
      background-color: #f2f2f2;
      border-radius: 5px;
      margin-left: 500px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    .btn-container {
      text-align: center;
    }

    .btn-container button {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .btn-container button:hover {
      background-color: #45a049;
    }

    nav {
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #ddd;
      height: 50px;
      position: fixed;
      top: 0;
      width: 100%;
    }
    
    nav ul {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
    }
    
    nav li {
      margin: 0 10px;
    }
    
    nav a {
      color: #000;
      text-decoration: none;
      font-size: 18px;
    }
  </style>
</head>
<br><br>
<br><br>
<body>
<nav>
    <ul>
      <li><a href="admin_homepage.php">Home</a></li>
      <li><a href="admin_reportedIncidents.php">Reported incident</a></li>
      <li><a href="admin_statistics.php">Reports</a></li>
      <li><a href="addUsertype.php">Usertype</a></li>
      <li><a href="addedStatus.php">Add status</a></li>
      <li><a href="addedAction.php">Add action</a></li>
      <li><a href="addedEmergency.php">Add emergency type</a></li>
      <li><a href="addedIntensity.php">Add Intensity</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <div class="container" >
<form action="addStatus.php" method="POST" onsubmit="return confirm('Are you sure you want to add this new status?');">
      <div class="form-group">
        <label for="textarea1">Add new status</label>
        <textarea name="textarea1" id="textarea1" rows="5" required></textarea>
      </div>
      <button type="submit" name="submit1" >Add new</button>
    </form>
</div>

  <div class="container">
  <h2>Added Status</h2>
  <table>
    <tr>
      <th>Status</th>
      <th>Action</th>
    </tr>
    <?php
    // Create a connection to the database
    $conn = new mysqli("localhost", "root", "", "ibrt_alert");

    // Check the connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve the data from the added_status table
    $sql = "SELECT AS_STATUS FROM added_status";
    $result = $conn->query($sql);

    // Check if there are any rows returned
    if ($result->num_rows > 0) {
      // Loop through each row and display the status
      while ($row = $result->fetch_assoc()) {
        $status = $row["AS_STATUS"];
        echo "<tr><td>$status</td>";
        echo "<td><form action='deleteStatus.php' method='POST' onsubmit=\"return confirm('Are you sure you want to delete this status?');\">";
        echo "<input type='hidden' name='status' value='$status'>";
        echo "<button type='submit'>Delete</button>";
        echo "</form></td></tr>";
      }
    } else {
      echo "<tr><td colspan='2'>No status added yet</td></tr>";
    }
    // Close the database connection
    $conn->close();
    ?>
  </table>
</div>

</body>

</html>





