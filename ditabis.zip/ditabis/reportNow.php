<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="homepageCSS.css">
        <title>Login Form</title>
        <style>
      html, body {
      min-height: 100%;
      }
      body, div, form, input, select { 
      padding: 0;
      margin: 0;
      outline: none;
      font-family: Roboto, Arial, sans-serif;
      font-size: 14px;
      color: #666;
      line-height: 22px;
      }
      h1, h4 {
      margin: 15px 0 4px;
      font-weight: 400;
      }
      h4 {
      margin: 20px 0 4px;
      font-weight: 400;
      }
      span {
      color: red;
      }
      .small {
      font-size: 10px;
      line-height: 18px;
      }
      .testbox {
      display: flex;
      justify-content: center;
      align-items: center;
      height: inherit;
      padding: 3px;
      }
      form {
      width: 100%;
      padding: 20px;
      background: #fff;
      box-shadow: 0 2px 5px #ccc; 
      }
      input {
      width: calc(100% - 10px);
      padding: 5px;
      border: 1px solid #ccc;
      border-radius: 3px;
      vertical-align: middle;
      }
      input:hover, textarea:hover, select:hover {
      outline: none;
      border: 1px solid #095484;
      background: #e6eef7;
      }
      .title-block select, .title-block input {
      margin-bottom: 10px;
      }
      select {
      padding: 7px 0;
      border-radius: 3px;
      border: 1px solid #ccc;
      background: transparent;
      }
      select, table {
      width: 100%;
      }
      option {
      background: #fff;
      }
      .day-visited, .time-visited {
      position: relative;
      }
      input[type="date"]::-webkit-inner-spin-button {
      display: none;
      }
      input[type="time"]::-webkit-inner-spin-button {
      margin: 2px 22px 0 0;
      }
      .day-visited i, .time-visited i, input[type="date"]::-webkit-calendar-picker-indicator {
      position: absolute;
      top: 8px;
      font-size: 20px;
      }
      .day-visited i, .time-visited i {
      right: 5px;
      z-index: 1;
      color: #a9a9a9;
      }
      [type="date"]::-webkit-calendar-picker-indicator {
      right: 0;
      z-index: 2;
      opacity: 0;
      }
      .question-answer label {
      display: block;
      padding: 0 20px 10px 0;
      }
      .question-answer input {
      width: auto;
      margin-top: -2px;
      }
      th, td {
      width: 18%;
      padding: 15px 0;
      border-bottom: 1px solid #ccc;
      text-align: center;
      vertical-align: unset;
      line-height: 18px;
      font-weight: 400;
      word-break: break-all;
      }
      .first-col {
      width: 25%;
      text-align: left;
      }
      textarea {
      width: calc(100% - 6px);
      }
      .btn-block {
      margin-top: 20px;
      text-align: center;
      }
      button {
      width: 150px;
      padding: 10px;
      border: none;
      -webkit-border-radius: 5px; 
      -moz-border-radius: 5px; 
      border-radius: 5px; 
      background-color: #095484;
      font-size: 16px;
      color: #fff;
      cursor: pointer;
      }
      button:hover {
      background-color: #0666a3;
      }
      @media (min-width: 568px) {
      .title-block {
      display: flex;
      justify-content: space-between;
      }
      .title-block select {
      width: 30%;
      margin-bottom: 0;
      }
      .title-block input {
      width: 31%;
      margin-bottom: 0;
      }
      th, td {
      word-break: keep-all;
      }
      }
      body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }
    </style>
</head>
<body>
<nav>
  <ul>
    <li><a href="homepage.php">Home</a></li>
    <li><a href="reportNow.php">Report now</a></li>
    <li><a href="reportedIncidents.php">Reported incident</a></li>
    <li><a href="#"><img src="logo.png" alt="Logo"></a></li>
    <li><a href="reportNow.php">Resolved reports</a></li>
    <li><a href="reportNow.php">Responders</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<br>
<br>
    <div class="testbox">
    <form action="reportNowDB.php" method="GET">
  <h1>Incident Report Form</h1>
  <h4>Type of Emergency<span>*</span></h4>
  <select name="emergency_type">
    <option value="emergency_type">
      

    <?php
  // Create a connection to the database
  $conn = new mysqli("localhost", "root", "", "ibrt_alert");

  // Check the connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Retrieve the data from the added_emergencytype table
  $sql = "SELECT AE_NAME FROM added_emergencytype";
  $result = $conn->query($sql);

  // Check if there are any rows returned
  if ($result->num_rows > 0) {
    // Loop through each row and display the emergency type as an option
    while ($row = $result->fetch_assoc()) {
      $emergencyType = $row["AE_NAME"];
      echo "<option value='$emergencyType'>$emergencyType</option>";
    }
  }

  // Close the database connection
  $conn->close();
  ?>
      </option>
  </select>


  
  <h4>Intensity/Seriousness <span>*</span></h4>
  <select name="intensity">
    <option value=""></option>
    <?php
    // Create connection to the database
    $conn = new mysqli("localhost", "root", "", "ibrt_alert");

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve the data from the added_intensity table
    $sql = "SELECT AI_NAME FROM added_intensity";
    $result = $conn->query($sql);

    // Check if there are any rows returned
    if ($result->num_rows > 0) {
        // Loop through each row and display the intensities as options
        while ($row = $result->fetch_assoc()) {
            $intensity = $row["AI_NAME"];
            echo "<option value='$intensity'>$intensity</option>";
        }
    }

    // Close the database connection
    $conn->close();
    ?>
</select>

  <h4>Specific location of the Incident<span>*</span></h4>
  <input type="text" name="location" />

  
  <h3>Description <span>*</span></h3>
  <p class="small">Use this space to provide a comprehensive and specific description of the incident, including any relevant information or observations.  </p>
  <textarea name="description" rows="5"></textarea>
  <p class="small">Please note that this form is for genuine incident reporting purposes only. Any false or misleading information provided as a joke or prank may result in serious consequences.</p>
  <div class="btn-block">
    <button type="submit" href="reportedIncidents.php">Submit Report</button>
  </div>

  
</form>

    </div>
  </body>






            
     
</html>