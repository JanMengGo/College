<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="homepageCSS.css">
<title>Login Form</title>
</head>

<body>
<nav>
  <ul>
    <li><a href="homepage.php">Home</a></li>
    <li><a href="reportNow.php">Report now</a></li>
    <li><a href="reportedIncidents.php">Reported incident</a></li>
    <li><a href="#"><img src="logo.png" alt="Logo"></a></li>
    <li><a href="reportNow.php">Resolved reports</a></li>
    <li><a href="reportNow.php">Responders</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>
<body>
<div class="containerHP">
  <div class="content-large"> Reported Incidents</div>
>
 <div class="content-small2">Latest Incidents</div>
 <div class="content-small3">Emergency Hotlines</div>
</div> 
  <footer>
    <p>&copy; 2023 IBRT Alert. All rights reserved.</p>
  </footer>
</body>

</html>