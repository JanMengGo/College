<?php
// Create connection to the database
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check the connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if the form has been submitted
if (isset($_POST['submit1'])) {
  // Get the major name from the form
  $majorName = $_POST['majorName'];

  // Generate a random ID
  $majorID = rand(100000000000, 999999999999);

  // Get the current date and time
  $dateAdded = date("Y-m-d H:i:s");

  // Insert the major into the added_major table
  $sql = "INSERT INTO added_major (AM_ID, AM_NAME, AM_DATEADDED) VALUES ('$majorID', '$majorName', '$dateAdded')";
  if ($conn->query($sql) === TRUE) {
    // Successfully added the major
    header("Location: addedMajor.php"); // Redirect back to the main page
    exit();
  } else {
    echo "Error adding major: " . $conn->error;
  }
}

// Close the database connection
$conn->close();
?>
