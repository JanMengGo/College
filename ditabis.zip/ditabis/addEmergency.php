<?php
// Create a connection to the database
$conn = new mysqli("localhost", "root", "", "ibrt_alert");

// Check the connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if the form has been submitted
if (isset($_POST['submit2'])) {
  // Get the emergency type from the form
  $emergencyType = $_POST['textarea2'];
  
  // Generate a unique ID for the emergency type
  $emergencyID = rand(pow(10,11), pow(10,12)-1);

  // Get the current date and time
  $dateAdded = date('Y-m-d H:i:s');

  // Insert the emergency type into the database
  $sql = "INSERT INTO added_emergencytype (AE_ID, AE_NAME, AE_DATEADDED) VALUES ('$emergencyID', '$emergencyType', '$dateAdded')";
  if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Emergency type added successfully');</script>";
        echo "<script>window.location = 'admin_homepage.php';</script>";

  } else {
    echo "Error adding emergency type: " . $conn->error;
  }
}

$conn->close();
?>
