<?php


// Check if the update button is clicked
if (isset($_POST['update'])) {
  // Retrieve the form data
  $status = $_POST['status'];
  $action = $_POST['action'];
  $remarks = $_POST['remarks'];
  $reportID = $_POST['reportID'];

  // Create a connection to the database
  $conn = new mysqli("localhost", "root", "", "ibrt_alert");

  // Check the connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Update the report in the database
  $sql = "UPDATE report_details SET RD_STATUS='$status', RD_ACTION='$action', RD_REMARKS='$remarks' WHERE RD_ID='$reportID'";

  if ($conn->query($sql) === TRUE) {
    echo "Report updated successfully";
  } else {
    echo "Error updating report: " . $conn->error;
  }

  // Close the database connection
  $conn->close();
}

// Redirect back to the reported incidents page after the update
header("Location: admin_reportedIncidents.php");
exit();
?>






