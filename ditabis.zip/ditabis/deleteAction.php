<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve the action value from the form
  $action = $_POST["action"];

  // Create a connection to the database
  $conn = new mysqli("localhost", "root", "", "ibrt_alert");

  // Check the connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Prepare and execute the SQL query to delete the action
  $sql = "DELETE FROM added_action WHERE AA_NAME = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("s", $action);
  $stmt->execute();

  // Check if the deletion was successful
  if ($stmt->affected_rows > 0) {
    echo "<script>
    alert('Action deleted successfully.');
    window.location.href = 'admin_updateReport.php';
</script>";
exit();
  } else {
    echo "Failed to delete action.";
  }

  // Close the statement and the database connection
  $stmt->close();
  $conn->close();
}
?>
