<?php
date_default_timezone_set('Asia/Manila');
// Check if the form is submitted
if (isset($_POST['submit1'])) {
    // Retrieve the textarea value
    $newStatus = $_POST['textarea1'];

    // Generate a unique ID with 12 digits
    $uniqueID = mt_rand(100000000000, 999999999999);

    // Get the current time
    $rdTime = ("H:i:s"); // Current time

    // Create a connection to the database
    $conn = new mysqli("localhost", "root", "", "ibrt_alert");

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL query to insert the new status
    $sql = "INSERT INTO added_status (AS_ID, AS_STATUS, AS_DATEADDED) VALUES ('$uniqueID', '$newStatus', '$rdTime')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New status added successfully!');</script>";
        echo "<script>window.location = 'admin_homepage.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    

    // Close the database connection
    $conn->close();
}


?>